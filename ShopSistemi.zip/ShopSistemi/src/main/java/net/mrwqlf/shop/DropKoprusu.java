package net.mrwqlf.shop;

import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Method;

/**
 * DropByDrop kuruluysa onun cop esyalarini NPC'de satin alir. Fiyat DropByDrop/config.yml'den gelir.
 * Esya kimligi PDC'dedir; oyuncu taklit edemez.
 */
public final class DropKoprusu {

    private Plugin eklenti;
    private Method yontem;

    private boolean bagla() {
        Plugin p = Bukkit.getPluginManager().getPlugin("DropByDrop");
        if (p == null || !p.isEnabled()) {
            return false;
        }
        if (p != eklenti) {
            try {
                yontem = p.getClass().getMethod("satisFiyati", ItemStack.class);
                eklenti = p;
            } catch (Throwable t) {
                return false;
            }
        }
        return true;
    }

    /** Adet basina satis fiyati; DropByDrop esyasi degilse veya kurulu degilse -1. */
    public long fiyat(ItemStack e) {
        if (e == null || !e.hasItemMeta() || !bagla()) {
            return -1;
        }
        try {
            return (long) yontem.invoke(eklenti, e);
        } catch (Throwable t) {
            return -1;
        }
    }
}
