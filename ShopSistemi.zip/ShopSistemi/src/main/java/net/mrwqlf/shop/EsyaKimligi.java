package net.mrwqlf.shop;

import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.Repairable;

/**
 * Ozel (sunucuya ozel) esyalari duz Minecraft esyalarindan ayirir.
 * Ornek: ozel "Hancer" (demir kilic tabanli) satilabilir; oyuncunun normal demir kilici
 * veya anvilde adi "Hancer" yapilmis demir kilici o urun olarak SATILAMAZ.
 */
public final class EsyaKimligi {

    private EsyaKimligi() {
    }

    /** Esya duz vanilla degil mi? (isim, lore, model, PDC, ozel attribute... tasiyor mu) */
    public static boolean ozelMi(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return false;
        }
        ItemMeta m = e.getItemMeta();
        return m.hasDisplayName() || m.hasLore() || m.hasItemModel()
                || m.hasCustomModelDataComponent()
                || m.hasAttributeModifiers()
                || !m.getPersistentDataContainer().getKeys().isEmpty();
    }

    /**
     * Taklit edilemez mi? Oyuncu anvilde isim/lore verebilir ama PDC, item_model ve
     * custom model data veremez. Yalnizca isim/lore ile ayirt edilen esyalar taklit edilebilir.
     */
    public static boolean dogrulanabilir(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return false;
        }
        ItemMeta m = e.getItemMeta();
        return m.hasItemModel() || m.hasCustomModelDataComponent()
                || !m.getPersistentDataContainer().getKeys().isEmpty();
    }

    private static ItemStack normal(ItemStack e) {
        ItemStack k = e.clone();
        k.setAmount(1);
        if (k.hasItemMeta()) {
            ItemMeta m = k.getItemMeta();
            if (m instanceof Damageable d) {
                d.setDamage(0);          // asinmis esya da ayni urundur
            }
            if (m instanceof Repairable r) {
                r.setRepairCost(0);      // anvil maliyeti fark yaratmasin
            }
            k.setItemMeta(m);
        }
        return k;
    }

    /** Iki esya ayni urun mu? Tur + ozel/duz ayrimi + tum meta (dayaniklilik haric). */
    public static boolean ayni(ItemStack a, ItemStack b) {
        if (a == null || b == null || a.getType() != b.getType()) {
            return false;
        }
        if (ozelMi(a) != ozelMi(b)) {
            return false;
        }
        return normal(a).isSimilar(normal(b));
    }
}
