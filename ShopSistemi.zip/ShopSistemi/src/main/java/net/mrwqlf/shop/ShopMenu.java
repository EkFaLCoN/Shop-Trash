package net.mrwqlf.shop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.Placeholder;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Menu cizimi + alis/satis mantigi. Her islem ana thread'de ve sunucu tarafinda dogrulanir. */
public final class ShopMenu {

    static final int SAYFA_BOYUTU = 45;
    static final int[] ADIMLAR = {1000, 100, 10};

    /** Bu eklentinin tum menuleri icin ortak tasiyici: tiklamalar hep iptal edilir. */
    abstract static class Tutucu implements InventoryHolder {
        protected Inventory envanter;

        @Override
        public Inventory getInventory() {
            return envanter;
        }
    }

    static final class AnaTutucu extends Tutucu {
        int sayfa;
        String kategori;   // null = kategori secim ekrani, "*" = tumu
    }

    record Kat(String id, String ad, Material ikon) {
    }

    static final int[] KAT_SLOT = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25};

    static final class DuzenleTutucu extends Tutucu {
        UUID urunId;
    }

    /** NPC satis menusu: ust 45 slot serbest birakma alani, alt satir duğmeler. */
    static final class SatisTutucu extends Tutucu {
        UUID npc;            // acan NPC (menuden acildiysa null)
        boolean yonetici;    // kaldirma dugmesi gorunsun mu
    }

    static final int NPC_KALDIR = 53;

    static final int SATIS_DUGME = 49;
    static final int SATIS_ALAN = 45;

    private final ShopSistemi eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final NumberFormat sayiBicimi = NumberFormat.getIntegerInstance(Locale.forLanguageTag("tr"));
    private final Set<UUID> duzenleyenler = new HashSet<>();
    private final Map<UUID, Long> sonTiklama = new HashMap<>();

    public ShopMenu(ShopSistemi eklenti) {
        this.eklenti = eklenti;
    }

    // ------------------------------------------------------------------ yardimcilar

    public void mesaj(Player p, String anahtar, TagResolver... cozucu) {
        String ham = eklenti.getConfig().getString("mesajlar." + anahtar, anahtar);
        p.sendMessage(mm.deserialize(ham, cozucu));
    }

    /** 1k = 1 bin, 1m = 1 milyon, 1b = 1 milyar (MarketAH ile ayni kisa gosterim). */
    private String para(long tutar) {
        double v;
        String ek;
        double a = Math.abs((double) tutar);
        if (a >= 1e15) { v = tutar / 1e15; ek = "q"; }
        else if (a >= 1e12) { v = tutar / 1e12; ek = "t"; }
        else if (a >= 1e9) { v = tutar / 1e9; ek = "b"; }
        else if (a >= 1e6) { v = tutar / 1e6; ek = "m"; }
        else if (a >= 1e3) { v = tutar / 1e3; ek = "k"; }
        else { v = tutar; ek = ""; }
        v = Math.floor(v * 100.0) / 100.0;
        String sayi = new java.text.DecimalFormat("0.##", java.text.DecimalFormatSymbols.getInstance(Locale.ROOT)).format(v);
        return sayi + ek + eklenti.getConfig().getString("para-birimi", "$");
    }

    private boolean yonetici(Player p) {
        return p.hasPermission("shop.admin");
    }

    boolean duzenleModunda(Player p) {
        if (duzenleyenler.contains(p.getUniqueId()) && !yonetici(p)) {
            duzenleyenler.remove(p.getUniqueId());
        }
        return duzenleyenler.contains(p.getUniqueId());
    }

    void oyuncuCikti(UUID id) {
        duzenleyenler.remove(id);
        sonTiklama.remove(id);
    }

    /** Cok hizli ardisik islemleri engeller. */
    boolean beklemeVar(Player p) {
        long simdi = System.currentTimeMillis();
        long bekleme = eklenti.getConfig().getLong("tiklama-bekleme-ms", 200L);
        Long son = sonTiklama.get(p.getUniqueId());
        if (son != null && simdi - son < bekleme) {
            return true;
        }
        sonTiklama.put(p.getUniqueId(), simdi);
        return false;
    }

    private Component yazi(String metin) {
        return mm.deserialize("<!italic>" + metin);
    }

    private ItemStack dugme(Material madde, String ad, String... lore) {
        ItemStack e = new ItemStack(madde);
        var meta = e.getItemMeta();
        meta.displayName(yazi(ad));
        List<Component> satirlar = new ArrayList<>();
        for (String s : lore) {
            satirlar.add(yazi(s));
        }
        meta.lore(satirlar);
        e.setItemMeta(meta);
        return e;
    }

    private ItemStack dolgu() {
        ItemStack e = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        var meta = e.getItemMeta();
        meta.displayName(Component.empty());
        e.setItemMeta(meta);
        return e;
    }

    /** Oyuncuya gosterilecek kopya: orijinal esyaya asla dokunulmaz. */
    private ItemStack vitrin(Urun u, boolean duzenle) {
        ItemStack e = u.esya.clone();
        e.setAmount(Math.min(u.miktar, e.getMaxStackSize()));
        var meta = e.getItemMeta();
        List<Component> lore = meta.lore() == null ? new ArrayList<>() : new ArrayList<>(meta.lore());
        lore.add(Component.empty());
        lore.add(yazi("<gray>Adet: <white>" + u.miktar));
        lore.add(yazi(u.alis > 0 ? "<green>Alış: <white>" + para(u.alis) : "<red>Alınamaz"));
        lore.add(yazi(u.satis > 0 ? "<gold>Satış (NPC): <white>" + para(u.satis) : "<red>Shop satın almıyor"));
        lore.add(Component.empty());
        if (duzenle) {
            lore.add(yazi("<yellow>Düzenlemek için tıkla"));
        } else {
            if (u.alis > 0) {
                lore.add(yazi("<green>Sol tık: <white>satın al"));
                lore.add(yazi("<green>Shift+Sol: <white>stack satın al"));
            }
            if (u.satis > 0) {
                lore.add(yazi("<gold>Satmak için: <white>Satış NPC'sine git"));
            }
        }
        meta.lore(lore);
        e.setItemMeta(meta);
        return e;
    }

    // ------------------------------------------------------------------ ana menu

    /** Kategori secim ekranini acar. */
    public void anaMenuAc(Player p, int sayfa) {
        anaMenuAc(p, null, 0);
    }

    public void anaMenuAc(Player p, String kategori, int sayfa) {
        AnaTutucu t = new AnaTutucu();
        t.sayfa = sayfa;
        t.kategori = kategori;
        t.envanter = Bukkit.createInventory(t, kategori == null ? 45 : 54,
                mm.deserialize(kategori == null ? "<dark_green><bold>SHOP • Kategoriler" : "<dark_green><bold>SHOP"));
        anaCiz(t, p);
        p.openInventory(t.envanter);
    }

    // ------------------------------------------------------------------ kategoriler

    List<Kat> kategoriler() {
        List<Kat> sonuc = new ArrayList<>();
        var kok = eklenti.getConfig().getConfigurationSection("kategoriler");
        if (kok != null) {
            for (String id : kok.getKeys(false)) {
                if (sonuc.size() >= KAT_SLOT.length) {
                    break;
                }
                Material ikon = Material.matchMaterial(kok.getString(id + ".ikon", "CHEST"));
                sonuc.add(new Kat(id, kok.getString(id + ".ad", id), ikon == null ? Material.CHEST : ikon));
            }
        }
        if (sonuc.isEmpty()) {
            sonuc.add(new Kat("diger", "Diğer", Material.CHEST));
        }
        return sonuc;
    }

    private Kat katBul(String id) {
        for (Kat k : kategoriler()) {
            if (k.id().equals(id)) {
                return k;
            }
        }
        return null;
    }

    private List<Urun> filtre(String kategori) {
        List<Urun> tum = eklenti.veri().urunler();
        if ("*".equals(kategori)) {
            return tum;
        }
        List<Urun> l = new ArrayList<>();
        for (Urun u : tum) {
            if (u.kategori.equals(kategori)) {
                l.add(u);
            }
        }
        return l;
    }

    private void katCiz(AnaTutucu t, Player p) {
        Inventory env = t.envanter;
        env.clear();
        for (int i = 0; i < 45; i++) {
            env.setItem(i, dolgu());
        }
        List<Kat> kats = kategoriler();
        for (int i = 0; i < kats.size(); i++) {
            Kat k = kats.get(i);
            env.setItem(KAT_SLOT[i], dugme(k.ikon(), "<yellow>" + k.ad(),
                    "<gray>Ürün sayısı: <white>" + filtre(k.id()).size(), "", "<green>Tıkla: aç"));
        }
        env.setItem(4, dugme(Material.ENDER_CHEST, "<aqua>Tüm ürünler",
                "<gray>Ürün sayısı: <white>" + eklenti.veri().urunler().size(), "", "<green>Tıkla: aç"));
        env.setItem(39, dugme(Material.GOLD_INGOT, "<gold>Eşya Sat",
                "<gray>Satış ekranını açar: eşyalarını koy,", "<gray>fiyatı gör ve tek tıkla sat."));
        env.setItem(40, dugme(Material.PAPER, "<white>Bakiye",
                eklenti.ekonomi().var()
                        ? "<gray>Bakiyen: <white>" + para((long) eklenti.ekonomi().bakiye(p))
                        : "<red>Ekonomi bulunamadı"));
        if (yonetici(p)) {
            boolean duzenle = duzenleModunda(p);
            env.setItem(41, dugme(duzenle ? Material.LIME_DYE : Material.GRAY_DYE,
                    duzenle ? "<green>Düzenleme modu: AÇIK" : "<gray>Düzenleme modu: KAPALI",
                    "<yellow>Tıkla: aç/kapat"));
        }
    }

    private void katTikla(Player p, AnaTutucu t, int slot) {
        if (slot == 4) {
            anaMenuAc(p, "*", 0);
            return;
        }
        if (slot == 39) {
            satisAc(p);
            return;
        }
        if (slot == 41 && yonetici(p)) {
            if (!duzenleyenler.remove(p.getUniqueId())) {
                duzenleyenler.add(p.getUniqueId());
            }
            anaCiz(t, p);
            return;
        }
        List<Kat> kats = kategoriler();
        for (int i = 0; i < kats.size(); i++) {
            if (KAT_SLOT[i] == slot) {
                anaMenuAc(p, kats.get(i).id(), 0);
                return;
            }
        }
    }

    void anaCiz(AnaTutucu t, Player p) {
        if (t.kategori == null) {
            katCiz(t, p);
            return;
        }
        Inventory env = t.envanter;
        env.clear();
        List<Urun> liste = filtre(t.kategori);
        int sayfaSayisi = Math.max(1, (liste.size() + SAYFA_BOYUTU - 1) / SAYFA_BOYUTU);
        t.sayfa = Math.max(0, Math.min(t.sayfa, sayfaSayisi - 1));
        boolean duzenle = duzenleModunda(p);

        int bas = t.sayfa * SAYFA_BOYUTU;
        for (int i = 0; i < SAYFA_BOYUTU && bas + i < liste.size(); i++) {
            env.setItem(i, vitrin(liste.get(bas + i), duzenle));
        }
        for (int i = 45; i < 54; i++) {
            env.setItem(i, dolgu());
        }
        if (t.sayfa > 0) {
            env.setItem(45, dugme(Material.ARROW, "<yellow>◀ Önceki sayfa"));
        }
        if (t.sayfa < sayfaSayisi - 1) {
            env.setItem(53, dugme(Material.ARROW, "<yellow>Sonraki sayfa ▶"));
        }
        env.setItem(49, dugme(Material.PAPER, "<white>Sayfa <yellow>" + (t.sayfa + 1) + "<gray>/<yellow>" + sayfaSayisi,
                eklenti.ekonomi().var()
                        ? "<gray>Bakiyen: <white>" + para((long) eklenti.ekonomi().bakiye(p))
                        : "<red>Ekonomi bulunamadı"));
        env.setItem(46, dugme(Material.BARRIER, "<yellow>◀ Kategoriler"));
        env.setItem(47, dugme(Material.GOLD_INGOT, "<gold>Eşya Sat",
                "<gray>Satış ekranını açar: eşyalarını koy,", "<gray>fiyatı gör ve tek tıkla sat."));
        if (yonetici(p)) {
            env.setItem(48, dugme(duzenle ? Material.LIME_DYE : Material.GRAY_DYE,
                    duzenle ? "<green>Düzenleme modu: AÇIK" : "<gray>Düzenleme modu: KAPALI",
                    "<yellow>Tıkla: aç/kapat"));
            if (duzenle) {
                env.setItem(50, dugme(Material.EMERALD, "<green>+ Elindeki eşyayı ekle",
                        "<gray>Eşyayı ana elinde tut ve tıkla."));
                env.setItem(52, dugme(Material.TNT, "<red>Tüm satış NPC'lerini kaldır",
                        "<gray>Onay için <white>SHIFT+tık"));
                env.setItem(51, dugme(Material.VILLAGER_SPAWN_EGG, "<gold>+ Satış NPC'si oluştur",
                        "<gray>Bulunduğun yere yerleşir.",
                        "<gray>Kaldırmak için: düzenleme modunda",
                        "<white>Shift+Sağ tık <gray>NPC'ye."));
            }
        }
    }

    void anaTikla(Player p, AnaTutucu t, int slot, ClickType tur) {
        if (t.kategori == null) {
            katTikla(p, t, slot);
            return;
        }
        if (slot == 46) {
            anaMenuAc(p, null, 0);
            return;
        }
        if (slot == 45 && t.sayfa > 0) {
            t.sayfa--;
            anaCiz(t, p);
            return;
        }
        if (slot == 53) {
            t.sayfa++;
            anaCiz(t, p);
            return;
        }
        if (slot == 47) {
            satisAc(p);
            return;
        }
        if (slot == 48 && yonetici(p)) {
            if (!duzenleyenler.remove(p.getUniqueId())) {
                duzenleyenler.add(p.getUniqueId());
            }
            anaCiz(t, p);
            return;
        }
        if (slot == 50 && duzenleModunda(p)) {
            urunEkle(p, t);
            return;
        }
        if (slot == 52 && duzenleModunda(p)) {
            if (tur.isShiftClick()) {
                int n = eklenti.npc().tumunuKaldir(p);
                p.closeInventory();
                p.sendMessage(mm.deserialize("<yellow>" + n + " satış NPC'si kaldırıldı."));
            }
            return;
        }
        if (slot == 51 && duzenleModunda(p)) {
            p.closeInventory();
            eklenti.npc().olustur(p);
            return;
        }
        if (slot < 0 || slot >= SAYFA_BOYUTU) {
            return;
        }
        List<Urun> liste = filtre(t.kategori);
        int idx = t.sayfa * SAYFA_BOYUTU + slot;
        if (idx >= liste.size()) {
            return;
        }
        Urun u = liste.get(idx);
        if (duzenleModunda(p)) {
            duzenleAc(p, u);
            return;
        }
        if (beklemeVar(p)) {
            return;
        }
        switch (tur) {
            case LEFT -> satinAl(p, u, 1);
            case SHIFT_LEFT -> satinAl(p, u, Math.max(1, u.esya.getMaxStackSize() / u.miktar));
            default -> {
            }
        }
        anaCiz(t, p);
    }

    private void urunEkle(Player p, AnaTutucu t) {
        ItemStack el = p.getInventory().getItemInMainHand();
        if (el.getType().isAir()) {
            mesaj(p, "eklenemedi-bos");
            return;
        }
        if (eklenti.veri().urunler().size() >= eklenti.getConfig().getInt("en-fazla-urun", 500)) {
            mesaj(p, "eklenemedi-limit");
            return;
        }
        if (EsyaKimligi.ozelMi(el) && !EsyaKimligi.dogrulanabilir(el)) {
            mesaj(p, "ekleme-uyari");
        }
        Urun u = new Urun(UUID.randomUUID(), el, 100, 0, 1);
        u.kategori = "*".equals(t.kategori) || katBul(t.kategori) == null ? "diger" : t.kategori;
        eklenti.veri().urunler().add(u);
        eklenti.veri().kaydet();
        mesaj(p, "eklendi");
        duzenleAc(p, u);
    }

    // ------------------------------------------------------------------ duzenleme menusu

    public void duzenleAc(Player p, Urun u) {
        if (!yonetici(p)) {
            mesaj(p, "yetkin-yok");
            return;
        }
        DuzenleTutucu t = new DuzenleTutucu();
        t.urunId = u.id;
        t.envanter = Bukkit.createInventory(t, 45, mm.deserialize("<dark_green>Ürün düzenle"));
        duzenleCiz(t);
        p.openInventory(t.envanter);
    }

    void duzenleCiz(DuzenleTutucu t) {
        Urun u = eklenti.veri().bul(t.urunId);
        Inventory env = t.envanter;
        env.clear();
        for (int i = 0; i < 45; i++) {
            env.setItem(i, dolgu());
        }
        if (u == null) {
            return;
        }
        env.setItem(4, vitrin(u, true));
        fiyatSatiri(env, 10, Material.GOLD_INGOT, "<green>Alış fiyatı (oyuncu öder)", u.alis);
        fiyatSatiri(env, 19, Material.EMERALD, "<gold>Satış fiyatı (oyuncu alır)", u.satis);
        env.setItem(29, dugme(Material.RED_STAINED_GLASS_PANE, "<red>-1 adet"));
        env.setItem(31, dugme(Material.CHEST, "<white>Adet: <yellow>" + u.miktar, "<gray>Tek tıklamada verilen/alınan"));
        env.setItem(33, dugme(Material.LIME_STAINED_GLASS_PANE, "<green>+1 adet"));
        Kat kat = katBul(u.kategori);
        env.setItem(38, dugme(kat == null ? Material.CHEST : kat.ikon(),
                "<white>Kategori: <yellow>" + (kat == null ? u.kategori : kat.ad()),
                "<gray>Tıkla: sonraki kategori"));
        env.setItem(36, dugme(Material.ARROW, "<yellow>◀ Geri"));
        env.setItem(40, dugme(Material.TNT, "<red>Ürünü sil", "<gray>Onay için <white>SHIFT+tık"));
        env.setItem(44, dugme(Material.BOOK, "<gray>Fiyat 0 = o işlem kapalı",
                "<gray>Shift+tık: adım x10"));
    }

    private void fiyatSatiri(Inventory env, int bas, Material madde, String ad, long deger) {
        for (int i = 0; i < 3; i++) {
            env.setItem(bas + i, dugme(Material.RED_STAINED_GLASS_PANE, "<red>-" + sayiBicimi.format(ADIMLAR[i])));
            env.setItem(bas + 4 + (2 - i), dugme(Material.LIME_STAINED_GLASS_PANE, "<green>+" + sayiBicimi.format(ADIMLAR[i])));
        }
        env.setItem(bas + 3, dugme(madde, ad, "<white>" + para(deger)));
    }

    void duzenleTikla(Player p, DuzenleTutucu t, int slot, ClickType tur) {
        if (!yonetici(p)) {
            p.closeInventory();
            mesaj(p, "yetkin-yok");
            return;
        }
        Urun u = eklenti.veri().bul(t.urunId);
        if (u == null) {
            p.closeInventory();
            return;
        }
        long maksFiyat = eklenti.getConfig().getLong("en-yuksek-fiyat", 1_000_000_000L);
        long carpan = tur.isShiftClick() ? 10 : 1;
        boolean degisti = false;

        if (slot == 36) {
            anaMenuAc(p, 0);
            return;
        }
        if (slot == 40) {
            if (tur.isShiftClick()) {
                eklenti.veri().urunler().remove(u);
                eklenti.veri().kaydet();
                mesaj(p, "silindi");
                anaMenuAc(p, 0);
            }
            return;
        }
        if (slot >= 10 && slot <= 16 && slot != 13) {
            long adim = adimBul(slot - 10);
            u.alis = Math.max(0, Math.min(maksFiyat, u.alis + adim * carpan));
            degisti = true;
        } else if (slot >= 19 && slot <= 25 && slot != 22) {
            long adim = adimBul(slot - 19);
            u.satis = Math.max(0, Math.min(maksFiyat, u.satis + adim * carpan));
            degisti = true;
        } else if (slot == 38) {
            List<Kat> kats = kategoriler();
            int i = 0;
            for (int k = 0; k < kats.size(); k++) {
                if (kats.get(k).id().equals(u.kategori)) {
                    i = k + 1;
                    break;
                }
            }
            u.kategori = kats.get(i % kats.size()).id();
            degisti = true;
        } else if (slot == 29) {
            u.miktar = Math.max(1, u.miktar - 1);
            degisti = true;
        } else if (slot == 33) {
            u.miktar = Math.min(u.esya.getMaxStackSize(), u.miktar + 1);
            degisti = true;
        }
        if (degisti) {
            eklenti.veri().kaydet();
            duzenleCiz(t);
        }
    }

    /** Konumdan (0..6) isaretli adimi verir: 0,1,2 negatif; 4,5,6 pozitif. */
    private long adimBul(int konum) {
        if (konum < 3) {
            return -ADIMLAR[konum];
        }
        if (konum > 3) {
            return ADIMLAR[6 - konum];
        }
        return 0;
    }

    // ------------------------------------------------------------------ alis / satis

    private int yerSayisi(Player p, ItemStack esya) {
        int yer = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null || s.getType().isAir()) {
                yer += esya.getMaxStackSize();
            } else if (s.isSimilar(esya)) {
                yer += Math.max(0, s.getMaxStackSize() - s.getAmount());
            }
        }
        return yer;
    }

    private int say(Player p, ItemStack esya) {
        int n = 0;
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s != null && s.isSimilar(esya)) {
                n += s.getAmount();
            }
        }
        return n;
    }

    private void esyaVer(Player p, ItemStack esya, int adet) {
        int kalan = adet;
        while (kalan > 0) {
            ItemStack parca = esya.clone();
            int n = Math.min(kalan, parca.getMaxStackSize());
            parca.setAmount(n);
            Map<Integer, ItemStack> artan = p.getInventory().addItem(parca);
            for (ItemStack a : artan.values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), a);
            }
            kalan -= n;
        }
    }

    private void satinAl(Player p, Urun u, int katsayi) {
        if (u.alis <= 0) {
            mesaj(p, "satilmiyor");
            return;
        }
        if (!eklenti.ekonomi().var()) {
            mesaj(p, "ekonomi-yok");
            return;
        }
        int adet = u.miktar * katsayi;
        long tutar = u.alis * katsayi;
        if (eklenti.ekonomi().bakiye(p) < tutar) {
            mesaj(p, "yetersiz-bakiye", Placeholder.unparsed("tutar", para(tutar)));
            return;
        }
        if (yerSayisi(p, u.esya) < adet) {
            mesaj(p, "envanter-dolu");
            return;
        }
        if (!eklenti.ekonomi().cek(p, tutar)) {
            mesaj(p, "yetersiz-bakiye", Placeholder.unparsed("tutar", para(tutar)));
            return;
        }
        esyaVer(p, u.esya, adet);
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 1.2f);
        mesaj(p, "satin-alindi", Placeholder.unparsed("adet", String.valueOf(adet)),
                Placeholder.component("esya", u.esya.effectiveName()),
                Placeholder.unparsed("tutar", para(tutar)));
    }

    // ------------------------------------------------------------------ NPC satis menusu

    public void satisAc(Player p) {
        satisAc(p, null);
    }

    public void satisAc(Player p, org.bukkit.entity.Entity npc) {
        SatisTutucu t = new SatisTutucu();
        t.npc = npc == null ? null : npc.getUniqueId();
        t.yonetici = npc != null && yonetici(p);
        t.envanter = Bukkit.createInventory(t, 54, mm.deserialize("<gold><bold>Satış Tüccarı"));
        satisCiz(t);
        p.openInventory(t.envanter);
    }

    void npcKaldir(Player p, SatisTutucu t) {
        if (!yonetici(p) || t.npc == null) {
            return;
        }
        org.bukkit.entity.Entity e = Bukkit.getEntity(t.npc);
        p.closeInventory();
        if (e != null) {
            eklenti.npc().kaldir(p, e);
        }
    }

    void satisCiz(SatisTutucu t) {
        Inventory env = t.envanter;
        for (int i = SATIS_ALAN; i < 54; i++) {
            env.setItem(i, dolgu());
        }
        if (t.yonetici) {
            env.setItem(NPC_KALDIR, dugme(Material.TNT, "<red>Bu NPC'yi kaldır",
                    "<gray>Onay için <white>SHIFT+tık"));
        }
        long toplam = satisToplam(env);
        env.setItem(SATIS_DUGME, dugme(toplam > 0 ? Material.EMERALD_BLOCK : Material.RED_CONCRETE,
                toplam > 0 ? "<green><bold>SAT" : "<red>Satılacak eşya yok",
                "<gray>Toplam: <white>" + para(toplam),
                "<gray>Satılamayan eşyalar kapatınca iade edilir."));
        env.setItem(45, dugme(Material.BOOK, "<yellow>Nasıl satılır?",
                "<gray>Eşyalarını yukarıdaki alana koy",
                "<gray>(envanterinden Shift+tık da olur),",
                "<gray>sonra <green>SAT <gray>düğmesine bas."));
    }

    private Urun satisUrunu(ItemStack s) {
        for (Urun u : eklenti.veri().urunler()) {
            if (u.satis > 0 && EsyaKimligi.ayni(u.esya, s)) {
                return u;
            }
        }
        return null;
    }

    private long satisToplam(Inventory env) {
        long toplam = 0;
        for (int i = 0; i < SATIS_ALAN; i++) {
            ItemStack s = env.getItem(i);
            if (s == null || s.getType().isAir()) {
                continue;
            }
            Urun u = satisUrunu(s);
            if (u != null) {
                toplam += u.satis * (s.getAmount() / u.miktar);
            } else {
                long f = eklenti.drop().fiyat(s);
                if (f > 0) {
                    toplam += f * s.getAmount();
                }
            }
        }
        return toplam;
    }

    /** Tiklamadan 1 tick sonra toplam fiyati yeniler (esya yerlesimi bitmis olur). */
    void satisYenileSonra(SatisTutucu t) {
        Bukkit.getScheduler().runTask(eklenti, () -> satisCiz(t));
    }

    void satisYap(Player p, SatisTutucu t) {
        if (beklemeVar(p)) {
            return;
        }
        if (!eklenti.ekonomi().var()) {
            mesaj(p, "ekonomi-yok");
            return;
        }
        Inventory env = t.envanter;
        long toplam = satisToplam(env);
        if (toplam <= 0) {
            mesaj(p, "satilacak-yok");
            return;
        }
        // Once parayi yatir; basariliysa esyalari al (ayni tick, arada degisiklik olamaz).
        if (!eklenti.ekonomi().yatir(p, toplam)) {
            mesaj(p, "ekonomi-yok");
            return;
        }
        int adet = 0;
        for (int i = 0; i < SATIS_ALAN; i++) {
            ItemStack s = env.getItem(i);
            if (s == null || s.getType().isAir()) {
                continue;
            }
            Urun u = satisUrunu(s);
            if (u == null) {
                if (eklenti.drop().fiyat(s) > 0) {
                    adet += s.getAmount();
                    env.setItem(i, null);
                }
                continue;
            }
            int satilan = (s.getAmount() / u.miktar) * u.miktar;
            if (satilan <= 0) {
                continue;
            }
            adet += satilan;
            if (satilan == s.getAmount()) {
                env.setItem(i, null);
            } else {
                ItemStack kalan = s.clone();
                kalan.setAmount(s.getAmount() - satilan);
                env.setItem(i, kalan);
            }
        }
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.8f, 0.8f);
        mesaj(p, "toplu-satildi", Placeholder.unparsed("adet", String.valueOf(adet)),
                Placeholder.unparsed("tutar", para(toplam)));
        satisCiz(t);
    }

    /** Menu kapaninca kalan her esya oyuncuya geri verilir. */
    void satisKapandi(Player p, SatisTutucu t) {
        Inventory env = t.envanter;
        for (int i = 0; i < SATIS_ALAN; i++) {
            ItemStack s = env.getItem(i);
            if (s == null || s.getType().isAir()) {
                continue;
            }
            env.setItem(i, null);
            for (ItemStack artan : p.getInventory().addItem(s).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), artan);
            }
        }
    }
}
