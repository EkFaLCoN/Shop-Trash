package net.mrwqlf.shop;

import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractAtEntityEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Shop menulerindeki HER etkilesim iptal edilir; esya cikarma/yerlestirme mumkun degildir. */
public final class ShopDinleyici implements Listener {

    private final ShopSistemi eklenti;
    private final ShopMenu menu;

    public ShopDinleyici(ShopSistemi eklenti, ShopMenu menu) {
        this.eklenti = eklenti;
        this.menu = menu;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof ShopMenu.Tutucu tutucu)) {
            return;
        }
        if (tutucu instanceof ShopMenu.SatisTutucu satis) {
            satisTikla(olay, satis);
            return;
        }
        // Ust/alt envanter, shift-tik, sayi tusu, cift tik, F tusu, birakma... hepsi iptal
        olay.setCancelled(true);
        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            return;
        }
        // Yalnizca ust (menu) envanterine yapilan tiklamalar islenir
        if (olay.getClickedInventory() == null
                || olay.getClickedInventory() != olay.getView().getTopInventory()) {
            return;
        }
        if (!oyuncu.hasPermission("shop.use")) {
            oyuncu.closeInventory();
            return;
        }
        if (tutucu instanceof ShopMenu.AnaTutucu ana) {
            menu.anaTikla(oyuncu, ana, olay.getSlot(), olay.getClick());
        } else if (tutucu instanceof ShopMenu.DuzenleTutucu duzenle) {
            menu.duzenleTikla(oyuncu, duzenle, olay.getSlot(), olay.getClick());
        }
    }

    /** Satis menusunde yalnizca ust 45 slot (birakma alani) serbesttir; dugme satiri korunur. */
    private void satisTikla(InventoryClickEvent olay, ShopMenu.SatisTutucu satis) {
        if (!(olay.getWhoClicked() instanceof Player oyuncu)) {
            olay.setCancelled(true);
            return;
        }
        if (!oyuncu.hasPermission("shop.use")) {
            olay.setCancelled(true);
            oyuncu.closeInventory();
            return;
        }
        ClickType tur = olay.getClick();
        // Cift tik / imlece toplama menudeki dugmeleri cekebilir -> tamamen kapali
        if (tur == ClickType.DOUBLE_CLICK || olay.getAction() == org.bukkit.event.inventory.InventoryAction.COLLECT_TO_CURSOR) {
            olay.setCancelled(true);
            return;
        }
        boolean ust = olay.getClickedInventory() == olay.getView().getTopInventory();
        if (ust && olay.getSlot() >= ShopMenu.SATIS_ALAN) {
            olay.setCancelled(true);
            if (olay.getSlot() == ShopMenu.SATIS_DUGME && (tur == ClickType.LEFT || tur == ClickType.SHIFT_LEFT)) {
                menu.satisYap(oyuncu, satis);
            }
            return;
        }
        // Digerleri serbest; toplam fiyat 1 tick sonra yenilenir
        menu.satisYenileSonra(satis);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void surukle(InventoryDragEvent olay) {
        var ust = olay.getView().getTopInventory();
        if (!(ust.getHolder() instanceof ShopMenu.Tutucu tutucu)) {
            return;
        }
        if (tutucu instanceof ShopMenu.SatisTutucu satis) {
            for (int slot : olay.getRawSlots()) {
                if (slot >= ShopMenu.SATIS_ALAN && slot < ust.getSize()) {
                    olay.setCancelled(true);
                    return;
                }
            }
            menu.satisYenileSonra(satis);
            return;
        }
        olay.setCancelled(true);
    }

    @EventHandler
    public void kapandi(InventoryCloseEvent olay) {
        if (olay.getInventory().getHolder() instanceof ShopMenu.SatisTutucu satis
                && olay.getPlayer() instanceof Player oyuncu) {
            menu.satisKapandi(oyuncu, satis);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void npcEtkilesim(PlayerInteractEntityEvent olay) {
        if (olay instanceof PlayerInteractAtEntityEvent && !eklenti.npc().npcMi(olay.getRightClicked())) {
            return;
        }
        if (!eklenti.npc().npcMi(olay.getRightClicked())) {
            return;
        }
        olay.setCancelled(true); // villager ticaret ekrani acilmasin
        if (olay instanceof PlayerInteractAtEntityEvent || olay.getHand() != EquipmentSlot.HAND) {
            return;
        }
        Player oyuncu = olay.getPlayer();
        if (oyuncu.isSneaking() && menu.duzenleModunda(oyuncu)) {
            eklenti.npc().kaldir(oyuncu, olay.getRightClicked());
            return;
        }
        if (!oyuncu.hasPermission("shop.use")) {
            menu.mesaj(oyuncu, "yetkin-yok");
            return;
        }
        menu.satisAc(oyuncu);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void npcHasar(EntityDamageEvent olay) {
        if (eklenti.npc().npcMi(olay.getEntity())) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void tasima(InventoryMoveItemEvent olay) {
        if (olay.getSource().getHolder() instanceof ShopMenu.Tutucu
                || olay.getDestination().getHolder() instanceof ShopMenu.Tutucu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void cikis(PlayerQuitEvent olay) {
        menu.oyuncuCikti(olay.getPlayer().getUniqueId());
    }
}
