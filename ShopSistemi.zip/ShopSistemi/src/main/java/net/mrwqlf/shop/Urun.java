package net.mrwqlf.shop;

import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/** Shop'taki tek bir urun. Fiyatlar tam sayidir (kayan nokta hatasi olmasin). */
public final class Urun {

    public final UUID id;
    public final ItemStack esya;   // her zaman amount = 1
    public long alis;              // oyuncunun ODEDIGI fiyat (0 = satin alinamaz)
    public long satis;             // oyuncunun ALDIGI fiyat (0 = shop almaz)
    public int miktar;             // tek tiklamada verilen/alinan adet

    public Urun(UUID id, ItemStack esya, long alis, long satis, int miktar) {
        this.id = id;
        ItemStack kopya = esya.clone();
        kopya.setAmount(1);
        this.esya = kopya;
        this.alis = alis;
        this.satis = satis;
        this.miktar = Math.max(1, miktar);
    }
}
