package net.mrwqlf.shop;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * ShopSistemi - esya ve fiyatlar oyun ici menuden eklenir.
 * Tek komut /shop'tur; alt komutu ve admin komutu YOKTUR (komut acigi yok).
 */
public final class ShopSistemi extends JavaPlugin {

    private Veri veri;
    private Ekonomi ekonomi;
    private ShopMenu menu;
    private SatisNpc npc;
    private final DropKoprusu drop = new DropKoprusu();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.veri = new Veri(this);
        this.veri.yukle();
        this.ekonomi = new Ekonomi();
        this.menu = new ShopMenu(this);
        this.npc = new SatisNpc(this);
        getServer().getPluginManager().registerEvents(new ShopDinleyici(this, menu), this);

        var komut = getCommand("shop");
        if (komut != null) {
            CommandExecutor yurutucu = (CommandSender g, Command k, String e, String[] a) -> {
                if (!(g instanceof Player oyuncu)) {
                    g.sendMessage("Bu komut yalnizca oyunculara ozeldir.");
                    return true;
                }
                if (!oyuncu.hasPermission("shop.use")) {
                    menu.mesaj(oyuncu, "yetkin-yok");
                    return true;
                }
                menu.anaMenuAc(oyuncu, 0);
                return true;
            };
            komut.setExecutor(yurutucu);
            // Alt komut yok: tab ile hicbir sey onerilmez
            komut.setTabCompleter((TabCompleter) (g, k, e, a) -> List.of());
        }
        getLogger().info("ShopSistemi acildi. Urun sayisi: " + veri.urunler().size());
    }

    @Override
    public void onDisable() {
        // Acik satis menulerindeki esyalar oyunculara geri verilsin
        for (org.bukkit.entity.Player o : getServer().getOnlinePlayers()) {
            if (o.getOpenInventory().getTopInventory().getHolder() instanceof ShopMenu.Tutucu) {
                o.closeInventory();
            }
        }
        if (veri != null) {
            veri.kaydet();
        }
    }

    public Veri veri() {
        return veri;
    }

    public ShopMenu menu() {
        return menu;
    }

    public DropKoprusu drop() {
        return drop;
    }

    public SatisNpc npc() {
        return npc;
    }

    public Ekonomi ekonomi() {
        return ekonomi;
    }
}
