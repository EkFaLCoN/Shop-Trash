package net.mrwqlf.shop;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

import java.lang.reflect.Method;

/** Vault ekonomisine yansima (reflection) ile baglanir; derleme icin Vault gerekmez. */
public final class Ekonomi {

    private Object saglayici;
    private Method bakiye;
    private Method cek;
    private Method yatir;
    private Method basarili;

    @SuppressWarnings({"unchecked", "rawtypes"})
    private boolean bagla() {
        if (saglayici != null) {
            return true;
        }
        try {
            Class<?> ekoSinif = Class.forName("net.milkbowl.vault.economy.Economy");
            RegisteredServiceProvider rsp = Bukkit.getServicesManager().getRegistration((Class) ekoSinif);
            if (rsp == null) {
                return false;
            }
            Object s = rsp.getProvider();
            Method b = ekoSinif.getMethod("getBalance", OfflinePlayer.class);
            Method c = ekoSinif.getMethod("withdrawPlayer", OfflinePlayer.class, double.class);
            Method y = ekoSinif.getMethod("depositPlayer", OfflinePlayer.class, double.class);
            Class<?> yanit = Class.forName("net.milkbowl.vault.economy.EconomyResponse");
            Method ok = yanit.getMethod("transactionSuccess");
            this.saglayici = s;
            this.bakiye = b;
            this.cek = c;
            this.yatir = y;
            this.basarili = ok;
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean var() {
        return bagla();
    }

    public double bakiye(OfflinePlayer o) {
        if (!bagla()) {
            return 0;
        }
        try {
            return (double) bakiye.invoke(saglayici, o);
        } catch (Throwable t) {
            return 0;
        }
    }

    public boolean cek(OfflinePlayer o, double miktar) {
        if (!bagla()) {
            return false;
        }
        try {
            return (boolean) basarili.invoke(cek.invoke(saglayici, o, miktar));
        } catch (Throwable t) {
            return false;
        }
    }

    public boolean yatir(OfflinePlayer o, double miktar) {
        if (!bagla()) {
            return false;
        }
        try {
            return (boolean) basarili.invoke(yatir.invoke(saglayici, o, miktar));
        } catch (Throwable t) {
            return false;
        }
    }
}
