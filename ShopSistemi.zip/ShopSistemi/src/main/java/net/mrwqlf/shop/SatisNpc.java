package net.mrwqlf.shop;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;

/** Satis NPC'si: AI'siz, olumsuz Villager. Komutsuz; menu uzerinden olusturulur/kaldirilir. */
public final class SatisNpc {

    private final ShopSistemi eklenti;
    private final NamespacedKey anahtar;

    public SatisNpc(ShopSistemi eklenti) {
        this.eklenti = eklenti;
        this.anahtar = new NamespacedKey(eklenti, "satis_npc");
    }

    public boolean npcMi(Entity e) {
        return e != null && e.getPersistentDataContainer().has(anahtar, PersistentDataType.BYTE);
    }

    public void olustur(Player p) {
        if (!p.hasPermission("shop.admin")) {
            return;
        }
        Location yer = p.getLocation();
        Villager npc = p.getWorld().spawn(yer, Villager.class, v -> {
            v.setAI(false);
            v.setInvulnerable(true);
            v.setSilent(true);
            v.setPersistent(true);
            v.setRemoveWhenFarAway(false);
            v.setCollidable(false);
            v.setProfession(Villager.Profession.NITWIT);
            v.customName(MiniMessage.miniMessage().deserialize("<gold><bold>Satış Tüccarı"));
            v.setCustomNameVisible(true);
            v.getPersistentDataContainer().set(anahtar, PersistentDataType.BYTE, (byte) 1);
        });
        npc.setRotation(yer.getYaw() + 180f, 0f);
        eklenti.menu().mesaj(p, "npc-olusturuldu");
    }

    public void kaldir(Player p, Entity e) {
        if (!p.hasPermission("shop.admin") || !npcMi(e)) {
            return;
        }
        e.remove();
        eklenti.menu().mesaj(p, "npc-silindi");
    }
}
