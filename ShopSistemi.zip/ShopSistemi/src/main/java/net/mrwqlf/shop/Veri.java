package net.mrwqlf.shop;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

/** Urunleri data.yml'de saklar (esyalar base64, meta/isim/enchant korunur). */
public final class Veri {

    private final ShopSistemi eklenti;
    private final File dosya;
    private final List<Urun> urunler = new ArrayList<>();

    public Veri(ShopSistemi eklenti) {
        this.eklenti = eklenti;
        this.dosya = new File(eklenti.getDataFolder(), "data.yml");
    }

    public List<Urun> urunler() {
        return urunler;
    }

    public Urun bul(UUID id) {
        for (Urun u : urunler) {
            if (u.id.equals(id)) {
                return u;
            }
        }
        return null;
    }

    public void yukle() {
        urunler.clear();
        if (!dosya.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(dosya);
        ConfigurationSection kok = yaml.getConfigurationSection("urunler");
        if (kok == null) {
            return;
        }
        for (String anahtar : kok.getKeys(false)) {
            try {
                ConfigurationSection b = kok.getConfigurationSection(anahtar);
                if (b == null) {
                    continue;
                }
                byte[] bayt = Base64.getDecoder().decode(b.getString("esya", ""));
                ItemStack esya = ItemStack.deserializeBytes(bayt);
                Urun yeni = new Urun(UUID.fromString(anahtar), esya,
                        Math.max(0, b.getLong("alis")), Math.max(0, b.getLong("satis")),
                        b.getInt("miktar", 1));
                yeni.kategori = b.getString("kategori", "diger");
                urunler.add(yeni);
            } catch (Exception e) {
                eklenti.getLogger().warning("Urun okunamadi (" + anahtar + "): " + e.getMessage());
            }
        }
    }

    public void kaydet() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Urun u : urunler) {
            String yol = "urunler." + u.id;
            yaml.set(yol + ".esya", Base64.getEncoder().encodeToString(u.esya.serializeAsBytes()));
            yaml.set(yol + ".alis", u.alis);
            yaml.set(yol + ".satis", u.satis);
            yaml.set(yol + ".miktar", u.miktar);
            yaml.set(yol + ".kategori", u.kategori);
        }
        try {
            eklenti.getDataFolder().mkdirs();
            File gecici = new File(eklenti.getDataFolder(), "data.yml.tmp");
            yaml.save(gecici);
            Files.move(gecici.toPath(), dosya.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            eklenti.getLogger().severe("data.yml kaydedilemedi: " + e.getMessage());
        }
    }
}
