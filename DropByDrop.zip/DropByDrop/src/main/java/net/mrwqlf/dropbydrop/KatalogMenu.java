package net.mrwqlf.dropbydrop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Yonetici ekranlari (hepsi /dropbydrop ile acilir, alt komut yok):
 *  - KATALOG : tikla = esyayi al. "Fiyat modu" acikken tikla = esyanin fiyatini duzenle
 *  - KADEME  : 6 kademenin satis fiyatini ayarla
 *  - ESYA    : tek esyanin ozel fiyati
 * Tum tiklamalar iptal edilir; yetki her tiklamada tekrar kontrol edilir.
 */
public final class KatalogMenu {

    static final int SAYFA = 45;
    static final long[] ADIM = {1, 10, 100, 1000};
    private static final String[] KADEME_AD = {"Paslı", "Yıpranmış", "Kırık", "Eski", "Yamalı", "Parlak"};

    enum Tur { KATALOG, KADEME, ESYA }

    static final class Tutucu implements InventoryHolder {
        Inventory envanter;
        Tur tur = Tur.KATALOG;
        int sayfa;
        boolean fiyatModu;
        Katalog.Tanim esya;   // ESYA ekraninda

        @Override
        public Inventory getInventory() {
            return envanter;
        }
    }

    private final DropByDrop eklenti;
    private final MiniMessage mm = MiniMessage.miniMessage();
    private final NumberFormat sayi = NumberFormat.getIntegerInstance(Locale.forLanguageTag("tr"));

    public KatalogMenu(DropByDrop eklenti) {
        this.eklenti = eklenti;
    }

    // ------------------------------------------------------------ yardimcilar

    private Component yazi(String s) {
        return mm.deserialize("<!italic>" + s);
    }

    private ItemStack dugme(Material m, String ad, String... lore) {
        ItemStack e = new ItemStack(m);
        var meta = e.getItemMeta();
        meta.displayName(yazi(ad));
        List<Component> l = new ArrayList<>();
        for (String s : lore) {
            l.add(yazi(s));
        }
        meta.lore(l);
        e.setItemMeta(meta);
        return e;
    }

    private ItemStack dolgu() {
        ItemStack d = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        var meta = d.getItemMeta();
        meta.displayName(Component.empty());
        d.setItemMeta(meta);
        return d;
    }

    private void doldur(Inventory env, int bas) {
        for (int i = bas; i < env.getSize(); i++) {
            env.setItem(i, dolgu());
        }
    }

    private String para(long v) {
        return sayi.format(v);
    }

    private void ac(Player p, Tutucu t, int boyut, String baslik) {
        t.envanter = Bukkit.createInventory(t, boyut, mm.deserialize(baslik));
        ciz(t);
        p.openInventory(t.envanter);
    }

    // ------------------------------------------------------------ acilis

    public void ac(Player p, int sayfa) {
        Tutucu t = new Tutucu();
        t.sayfa = sayfa;
        ac(p, t, 54, "<dark_gray>DropByDrop katalog");
    }

    private void kademeAc(Player p, Tutucu eski) {
        Tutucu t = new Tutucu();
        t.tur = Tur.KADEME;
        t.sayfa = eski.sayfa;
        t.fiyatModu = eski.fiyatModu;
        ac(p, t, 54, "<dark_gray>Kademe satış fiyatları");
    }

    private void esyaAc(Player p, Tutucu eski, Katalog.Tanim tanim) {
        Tutucu t = new Tutucu();
        t.tur = Tur.ESYA;
        t.sayfa = eski.sayfa;
        t.fiyatModu = true;
        t.esya = tanim;
        ac(p, t, 27, "<dark_gray>Esya satış fiyatı");
    }

    private void katalogAc(Player p, Tutucu eski) {
        Tutucu t = new Tutucu();
        t.sayfa = eski.sayfa;
        t.fiyatModu = eski.fiyatModu;
        ac(p, t, 54, "<dark_gray>DropByDrop katalog");
    }

    // ------------------------------------------------------------ cizim

    void ciz(Tutucu t) {
        switch (t.tur) {
            case KATALOG -> katalogCiz(t);
            case KADEME -> kademeCiz(t);
            case ESYA -> esyaCiz(t);
        }
    }

    private void katalogCiz(Tutucu t) {
        List<Katalog.Tanim> liste = eklenti.katalog().hepsi();
        int sayfaSayisi = Math.max(1, (liste.size() + SAYFA - 1) / SAYFA);
        t.sayfa = Math.max(0, Math.min(t.sayfa, sayfaSayisi - 1));
        Inventory env = t.envanter;
        env.clear();
        int bas = t.sayfa * SAYFA;
        for (int i = 0; i < SAYFA && bas + i < liste.size(); i++) {
            Katalog.Tanim tn = liste.get(bas + i);
            ItemStack e = eklenti.katalog().uret(tn);
            var meta = e.getItemMeta();
            List<Component> lore = new ArrayList<>(meta.lore() == null ? List.of() : meta.lore());
            lore.add(Component.empty());
            lore.add(yazi("<gold>Satış fiyatı: <white>" + para(eklenti.fiyat(tn))
                    + (eklenti.ozelFiyatVarMi(tn) ? " <gray>(özel)" : " <gray>(kademe)")));
            lore.add(yazi(t.fiyatModu ? "<yellow>Fiyatı düzenlemek için tıkla" : "<green>Almak için tıkla"));
            meta.lore(lore);
            e.setItemMeta(meta);
            env.setItem(i, e);
        }
        doldur(env, 45);
        if (t.sayfa > 0) {
            env.setItem(45, dugme(Material.ARROW, "<yellow>◀ Önceki"));
        }
        if (t.sayfa < sayfaSayisi - 1) {
            env.setItem(53, dugme(Material.ARROW, "<yellow>Sonraki ▶"));
        }
        env.setItem(49, dugme(Material.PAPER, "<white>Sayfa " + (t.sayfa + 1) + "/" + sayfaSayisi));
        env.setItem(48, dugme(t.fiyatModu ? Material.LIME_DYE : Material.GRAY_DYE,
                t.fiyatModu ? "<green>Fiyat modu: AÇIK" : "<gray>Fiyat modu: KAPALI",
                "<yellow>Tıkla: aç/kapat", "<gray>Açıkken eşyaya tıklayıp özel fiyat ver"));
        env.setItem(50, dugme(Material.GOLD_INGOT, "<gold>Kademe fiyatları",
                "<gray>6 kademenin satış fiyatını ayarla"));
    }

    private void kademeCiz(Tutucu t) {
        Inventory env = t.envanter;
        env.clear();
        doldur(env, 0);
        Material[] ornek = {Material.COPPER_INGOT, Material.IRON_NUGGET, Material.COAL, Material.IRON_INGOT,
                Material.LEATHER, Material.DIAMOND};
        for (int k = 1; k <= 6; k++) {
            int satir = (k - 1) * 9;
            env.setItem(satir, dugme(ornek[k - 1], "<white>Kademe " + k + " <gray>· " + KADEME_AD[k - 1]));
            long[] adim = {-1000, -100, -10, 0, 10, 100, 1000};
            for (int i = 0; i < 7; i++) {
                int slot = satir + 1 + i;
                if (i == 3) {
                    env.setItem(slot, dugme(Material.GOLD_NUGGET, "<gold>" + para(eklenti.kademeFiyati(k))));
                } else {
                    env.setItem(slot, dugme(adim[i] < 0 ? Material.RED_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE,
                            (adim[i] < 0 ? "<red>" : "<green>+") + para(adim[i]),
                            "<gray>Shift+tık: x10"));
                }
            }
        }
        env.setItem(8, dugme(Material.ARROW, "<yellow>◀ Geri"));
    }

    private void esyaCiz(Tutucu t) {
        Inventory env = t.envanter;
        env.clear();
        doldur(env, 0);
        Katalog.Tanim tn = t.esya;
        env.setItem(4, eklenti.katalog().uret(tn));
        long[] adim = {-1, -10, -100, -1000, 1000, 100, 10, 1};
        int[] slot = {9, 10, 11, 12, 14, 15, 16, 17};
        for (int i = 0; i < 8; i++) {
            env.setItem(slot[i], dugme(adim[i] < 0 ? Material.RED_STAINED_GLASS_PANE : Material.LIME_STAINED_GLASS_PANE,
                    (adim[i] < 0 ? "<red>" : "<green>+") + para(adim[i]), "<gray>Shift+tık: x10"));
        }
        env.setItem(13, dugme(Material.GOLD_INGOT, "<gold>Satış fiyatı: <white>" + para(eklenti.fiyat(tn)),
                eklenti.ozelFiyatVarMi(tn) ? "<gray>Özel fiyat" : "<gray>Kademe fiyatı (" + tn.kademe() + ")"));
        env.setItem(22, dugme(Material.BARRIER, "<red>Kademe fiyatına dön", "<gray>Özel fiyatı kaldırır"));
        env.setItem(18, dugme(Material.ARROW, "<yellow>◀ Geri"));
    }

    // ------------------------------------------------------------ tiklama

    void tikla(Player p, Tutucu t, int slot, ClickType tur) {
        if (!p.hasPermission("dropbydrop.admin")) {
            p.closeInventory();
            return;
        }
        long carpan = tur.isShiftClick() ? 10 : 1;
        switch (t.tur) {
            case KATALOG -> katalogTikla(p, t, slot);
            case KADEME -> {
                if (slot == 8) {
                    katalogAc(p, t);
                    return;
                }
                int k = slot / 9 + 1;
                int i = slot % 9 - 1;
                if (k < 1 || k > 6 || i < 0 || i > 6 || i == 3) {
                    return;
                }
                long[] adim = {-1000, -100, -10, 0, 10, 100, 1000};
                eklenti.kademeFiyatAyarla(k, eklenti.kademeFiyati(k) + adim[i] * carpan);
                ciz(t);
            }
            case ESYA -> {
                if (slot == 18) {
                    katalogAc(p, t);
                    return;
                }
                if (slot == 22) {
                    eklenti.ozelFiyatAyarla(t.esya, -1);
                    ciz(t);
                    return;
                }
                long[] adim = {-1, -10, -100, -1000, 1000, 100, 10, 1};
                int[] slotlar = {9, 10, 11, 12, 14, 15, 16, 17};
                for (int i = 0; i < 8; i++) {
                    if (slotlar[i] == slot) {
                        eklenti.ozelFiyatAyarla(t.esya, Math.max(0, eklenti.fiyat(t.esya) + adim[i] * carpan));
                        ciz(t);
                        return;
                    }
                }
            }
        }
    }

    private void katalogTikla(Player p, Tutucu t, int slot) {
        if (slot == 45 && t.sayfa > 0) {
            t.sayfa--;
            ciz(t);
        } else if (slot == 53) {
            t.sayfa++;
            ciz(t);
        } else if (slot == 48) {
            t.fiyatModu = !t.fiyatModu;
            ciz(t);
        } else if (slot == 50) {
            kademeAc(p, t);
        } else if (slot >= 0 && slot < SAYFA) {
            List<Katalog.Tanim> liste = eklenti.katalog().hepsi();
            int idx = t.sayfa * SAYFA + slot;
            if (idx >= liste.size()) {
                return;
            }
            Katalog.Tanim tn = liste.get(idx);
            if (t.fiyatModu) {
                esyaAc(p, t, tn);
                return;
            }
            for (ItemStack artan : p.getInventory().addItem(eklenti.katalog().uret(tn)).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), artan);
            }
        }
    }
}
