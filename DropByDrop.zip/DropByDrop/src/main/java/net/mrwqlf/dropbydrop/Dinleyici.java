package net.mrwqlf.dropbydrop;

import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class Dinleyici implements Listener {

    private final DropByDrop eklenti;
    private final KatalogMenu menu;

    public Dinleyici(DropByDrop eklenti, KatalogMenu menu) {
        this.eklenti = eklenti;
        this.menu = menu;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof KatalogMenu.Tutucu t)) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getWhoClicked() instanceof Player p
                && olay.getClickedInventory() == olay.getView().getTopInventory()) {
            menu.tikla(p, t, olay.getSlot(), olay.getClick());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void surukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof KatalogMenu.Tutucu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void olum(EntityDeathEvent olay) {
        var cfg = eklenti.getConfig();
        if (!cfg.getBoolean("drop.aktif", true) || !(olay.getEntity() instanceof Monster)) {
            return;
        }
        if (cfg.getBoolean("drop.sadece-oyuncu-oldurunce", true) && olay.getEntity().getKiller() == null) {
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (r.nextDouble() >= cfg.getDouble("drop.sans", 0.04)) {
            return;
        }
        // Kademe agirlikli secim
        List<Integer> agirlik = cfg.getIntegerList("drop.kademe-agirlik");
        int toplam = 0;
        for (int a : agirlik) {
            toplam += Math.max(0, a);
        }
        int kademe = 1;
        if (toplam > 0) {
            int z = r.nextInt(toplam);
            for (int i = 0; i < agirlik.size(); i++) {
                z -= Math.max(0, agirlik.get(i));
                if (z < 0) {
                    kademe = i + 1;
                    break;
                }
            }
        }
        final int k = kademe;
        List<Katalog.Tanim> aday = eklenti.katalog().hepsi().stream().filter(t -> t.kademe() == k).toList();
        if (aday.isEmpty()) {
            return;
        }
        olay.getDrops().add(eklenti.katalog().uret(aday.get(r.nextInt(aday.size()))));
    }
}
