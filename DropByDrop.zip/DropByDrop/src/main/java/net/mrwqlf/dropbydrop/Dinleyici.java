package net.mrwqlf.dropbydrop;

import org.bukkit.Bukkit;
import org.bukkit.entity.Monster;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.block.BlockDispenseArmorEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class Dinleyici implements Listener {

    private final DropByDrop eklenti;
    private final KatalogMenu menu;

    public Dinleyici(DropByDrop eklenti, KatalogMenu menu) {
        this.eklenti = eklenti;
        this.menu = menu;
        // Guvenlik agi: bir sekilde giyilen cop zirh her 0.5 sn'de cikarilip envantere iade edilir
        Bukkit.getScheduler().runTaskTimer(eklenti, () -> {
            for (Player p : Bukkit.getOnlinePlayers()) {
                zirhTemizle(p);
            }
        }, 20L, 10L);
    }

    private boolean copMu(ItemStack e) {
        return e != null && !e.getType().isAir() && eklenti.katalog().tanimi(e) != null;
    }

    /** Katalog esyasi, zirh yuvasina giyilebilen bir malzeme mi? */
    private boolean giyilemez(ItemStack e) {
        if (!copMu(e)) {
            return false;
        }
        EquipmentSlot s = e.getType().getEquipmentSlot();
        return s == EquipmentSlot.HEAD || s == EquipmentSlot.CHEST || s == EquipmentSlot.LEGS || s == EquipmentSlot.FEET;
    }

    private void reddet(Player p) {
        p.sendMessage(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage()
                .deserialize(eklenti.getConfig().getString("mesajlar.giyilemez", "<red>Çöp eşyalar giyilemez.")));
        p.playSound(p.getLocation(), org.bukkit.Sound.ENTITY_VILLAGER_NO, 1f, 0.9f);
    }

    private void zirhTemizle(Player p) {
        PlayerInventory env = p.getInventory();
        ItemStack[] z = env.getArmorContents();
        boolean degisti = false;
        for (int i = 0; i < z.length; i++) {
            if (giyilemez(z[i])) {
                ItemStack parca = z[i];
                z[i] = null;
                degisti = true;
                env.setArmorContents(z);
                for (ItemStack artan : env.addItem(parca).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), artan);
                }
                reddet(p);
            }
        }
        if (degisti) {
            p.updateInventory();
        }
    }

    /** Zirh yuvasina tikla / imlecle / sayi tusu / shift-tik ile giyme denemeleri. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void giyme(InventoryClickEvent olay) {
        if (!(olay.getWhoClicked() instanceof Player p)) {
            return;
        }
        if (olay.getSlotType() == InventoryType.SlotType.ARMOR) {
            if (giyilemez(olay.getCursor())) {
                olay.setCancelled(true);
                reddet(p);
                return;
            }
            if (olay.getClick() == org.bukkit.event.inventory.ClickType.NUMBER_KEY && olay.getHotbarButton() >= 0
                    && giyilemez(p.getInventory().getItem(olay.getHotbarButton()))) {
                olay.setCancelled(true);
                reddet(p);
                return;
            }
            if (olay.getClick() == org.bukkit.event.inventory.ClickType.SWAP_OFFHAND
                    && giyilemez(p.getInventory().getItemInOffHand())) {
                olay.setCancelled(true);
                reddet(p);
                return;
            }
        }
        if (olay.isShiftClick() && olay.getView().getTopInventory().getType() == InventoryType.CRAFTING
                && olay.getClickedInventory() != null
                && olay.getClickedInventory().getType() == InventoryType.PLAYER
                && giyilemez(olay.getCurrentItem())) {
            olay.setCancelled(true);
            reddet(p);
        }
    }

    /** Sag tikla giyme. */
    @EventHandler(priority = EventPriority.HIGH)
    public void sagTik(PlayerInteractEvent olay) {
        if (giyilemez(olay.getItem())) {
            olay.setUseItemInHand(org.bukkit.event.Event.Result.DENY);
            olay.setCancelled(true);
            reddet(olay.getPlayer());
        }
    }

    /** Dispenser ile giydirme. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void dispenser(BlockDispenseArmorEvent olay) {
        if (giyilemez(olay.getItem())) {
            olay.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof KatalogMenu.Tutucu t)) {
            return;
        }
        olay.setCancelled(true);
        if (olay.getWhoClicked() instanceof Player p
                && olay.getClickedInventory() == olay.getView().getTopInventory()) {
            menu.tikla(p, t, olay.getSlot(), olay.getClick());
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void surukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof KatalogMenu.Tutucu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void olum(EntityDeathEvent olay) {
        var cfg = eklenti.getConfig();
        if (!cfg.getBoolean("drop.aktif", true) || !(olay.getEntity() instanceof Monster)) {
            return;
        }
        if (cfg.getBoolean("drop.sadece-oyuncu-oldurunce", true) && olay.getEntity().getKiller() == null) {
            return;
        }
        ThreadLocalRandom r = ThreadLocalRandom.current();
        if (r.nextDouble() >= cfg.getDouble("drop.sans", 0.04)) {
            return;
        }
        // Kademe agirlikli secim
        List<Integer> agirlik = new java.util.ArrayList<>(cfg.getIntegerList("drop.kademe-agirlik"));
        while (agirlik.size() < 7) {
            agirlik.add(agirlik.size() == 6 ? 1 : 0);   // eski config: Kadim kademe agirligi 1
        }
        int toplam = 0;
        for (int a : agirlik) {
            toplam += Math.max(0, a);
        }
        int kademe = 1;
        if (toplam > 0) {
            int z = r.nextInt(toplam);
            for (int i = 0; i < agirlik.size(); i++) {
                z -= Math.max(0, agirlik.get(i));
                if (z < 0) {
                    kademe = i + 1;
                    break;
                }
            }
        }
        final int k = kademe;
        List<Katalog.Tanim> aday = eklenti.katalog().hepsi().stream().filter(t -> t.kademe() == k).toList();
        if (aday.isEmpty()) {
            return;
        }
        olay.getDrops().add(eklenti.katalog().uret(aday.get(r.nextInt(aday.size()))));
    }
}
