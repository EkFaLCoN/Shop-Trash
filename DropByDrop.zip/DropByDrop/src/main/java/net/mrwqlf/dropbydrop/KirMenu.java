package net.mrwqlf.dropbydrop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataType;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

/** /salvage (/kir): Parlak ve Kadim cop esyalari kirip shard kazanma menusu. */
public final class KirMenu implements Listener {

    private static final int BOYUT = 54;
    private static final int GIRIS_SON = 44;      // 0..44 : esya koyma alani
    private static final int ONAY = 49;
    private static final MiniMessage MM = MiniMessage.miniMessage();

    private final DropByDrop eklenti;
    private final NamespacedKey yerKey;

    public KirMenu(DropByDrop eklenti) {
        this.eklenti = eklenti;
        this.yerKey = new NamespacedKey(eklenti, "kir_yer");
    }

    public static final class Tutucu implements InventoryHolder {
        private Inventory env;

        @Override
        public Inventory getInventory() {
            return env;
        }
    }

    private String mesaj(String anahtar) {
        return eklenti.getConfig().getString("mesajlar." + anahtar, "");
    }

    private ItemStack dugme(Material m, String ad, String... lore) {
        ItemStack e = new ItemStack(m);
        ItemMeta meta = e.getItemMeta();
        meta.displayName(MM.deserialize("<!italic>" + ad));
        meta.lore(java.util.Arrays.stream(lore).map(l -> MM.deserialize("<!italic>" + l)).toList());
        meta.getPersistentDataContainer().set(yerKey, PersistentDataType.BYTE, (byte) 1);
        e.setItemMeta(meta);
        return e;
    }

    private boolean yerTutucu(ItemStack e) {
        return e != null && e.hasItemMeta()
                && e.getItemMeta().getPersistentDataContainer().has(yerKey, PersistentDataType.BYTE);
    }

    public void ac(Player p) {
        Tutucu t = new Tutucu();
        t.env = Bukkit.createInventory(t, BOYUT, MM.deserialize("<dark_gray>Eşya Kır <gray>· <aqua>Shard"));
        ItemStack cam = dugme(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = GIRIS_SON + 1; i < BOYUT; i++) {
            t.env.setItem(i, cam);
        }
        t.env.setItem(ONAY, dugme(Material.ANVIL, "<green>✔ Onayla ve Kır",
                "<gray>Yukarıya koyduğun <aqua>Parlak <gray>ve <gold>Kadim <gray>eşyalar kırılır.",
                "<gray>Silah → Silah Shard'ı, Zırh → Zırh Shard'ı",
                "<gray>Eşya başına <white>1-3 <gray>shard"));
        t.env.setItem(45, dugme(Material.BOOK, "<yellow>Nasıl çalışır?",
                "<gray>Envanterindeki eşyaya tıkla → buraya girer.",
                "<gray>Buradaki eşyaya tıkla → geri alırsın.",
                "<aqua>Parlak <gray>(kademe 6) → <aqua>Güçlü <gray>shard",
                "<gold>Kadim <gray>(kademe 7) → <gold>Efsanevi <gray>shard"));
        p.openInventory(t.env);
    }

    private boolean kirilir(ItemStack e) {
        Katalog.Tanim t = eklenti.katalog().tanimi(e);
        return t != null && t.kademe() >= 6;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void tikla(InventoryClickEvent olay) {
        if (!(olay.getView().getTopInventory().getHolder() instanceof Tutucu t)
                || !(olay.getWhoClicked() instanceof Player p)) {
            return;
        }
        olay.setCancelled(true);
        Inventory ust = olay.getView().getTopInventory();
        ItemStack tik = olay.getCurrentItem();
        if (tik == null || tik.getType().isAir() || yerTutucu(tik) && olay.getRawSlot() != ONAY) {
            return;
        }
        if (olay.getClickedInventory() == ust) {
            int slot = olay.getRawSlot();
            if (slot == ONAY) {
                kir(p, t);
            } else if (slot <= GIRIS_SON) {
                // geri al
                ust.setItem(slot, null);
                for (ItemStack artan : p.getInventory().addItem(tik).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), artan);
                }
            }
            return;
        }
        // oyuncu envanterinden alana tasi
        if (olay.getClickedInventory() != p.getInventory()) {
            return;
        }
        if (eklenti.katalog().tanimi(tik) == null) {
            p.sendMessage(MM.deserialize(mesaj("kir-cop-degil")));
            return;
        }
        if (!kirilir(tik)) {
            p.sendMessage(MM.deserialize(mesaj("kir-dusuk")));
            return;
        }
        for (int i = 0; i <= GIRIS_SON; i++) {
            if (ust.getItem(i) == null) {
                ust.setItem(i, tik.clone());
                olay.getClickedInventory().setItem(olay.getSlot(), null);
                return;
            }
        }
        p.sendMessage(MM.deserialize(mesaj("kir-dolu")));
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void surukle(InventoryDragEvent olay) {
        if (olay.getView().getTopInventory().getHolder() instanceof Tutucu) {
            olay.setCancelled(true);
        }
    }

    @EventHandler
    public void kapandi(InventoryCloseEvent olay) {
        if (!(olay.getInventory().getHolder() instanceof Tutucu) || !(olay.getPlayer() instanceof Player p)) {
            return;
        }
        for (int i = 0; i <= GIRIS_SON; i++) {
            ItemStack e = olay.getInventory().getItem(i);
            if (e != null && !yerTutucu(e)) {
                olay.getInventory().setItem(i, null);
                for (ItemStack artan : p.getInventory().addItem(e).values()) {
                    p.getWorld().dropItemNaturally(p.getLocation(), artan);
                }
            }
        }
    }

    private void kir(Player p, Tutucu t) {
        Inventory env = t.env;
        var upgrade = Bukkit.getPluginManager().getPlugin("UpgradeSistemi");
        java.lang.reflect.Method uret = null;
        Object esyalar = null;
        try {
            if (upgrade != null && upgrade.isEnabled()) {
                esyalar = upgrade.getClass().getMethod("esyalar").invoke(upgrade);
                uret = esyalar.getClass().getMethod("uret", String.class, int.class);
            }
        } catch (ReflectiveOperationException | RuntimeException hata) {
            uret = null;
        }
        if (uret == null) {
            p.sendMessage(MM.deserialize(mesaj("kir-eklenti-yok")));
            return;
        }
        int min = Math.max(1, eklenti.getConfig().getInt("kirma.min-shard", 1));
        int maks = Math.max(min, eklenti.getConfig().getInt("kirma.max-shard", 3));
        ThreadLocalRandom r = ThreadLocalRandom.current();
        Map<String, Integer> toplam = new LinkedHashMap<>();
        int adet = 0;
        for (int i = 0; i <= GIRIS_SON; i++) {
            ItemStack e = env.getItem(i);
            if (e == null || yerTutucu(e)) {
                continue;
            }
            Katalog.Tanim tn = eklenti.katalog().tanimi(e);
            if (tn == null || tn.kademe() < 6) {
                continue;           // kapanista iade edilir
            }
            String tur = "shard_" + (tn.tur().equals("silah") ? "weapon" : "armor") + (tn.kademe() >= 7 ? "_e" : "_g");
            for (int n = 0; n < e.getAmount(); n++) {
                toplam.merge(tur, r.nextInt(min, maks + 1), Integer::sum);
            }
            adet += e.getAmount();
            env.setItem(i, null);
        }
        if (adet == 0) {
            p.sendMessage(MM.deserialize(mesaj("kir-bos")));
            return;
        }
        StringBuilder ozet = new StringBuilder();
        try {
            for (Map.Entry<String, Integer> g : toplam.entrySet()) {
                int kalan = g.getValue();
                while (kalan > 0) {
                    int parca = Math.min(64, kalan);
                    ItemStack shard = (ItemStack) uret.invoke(esyalar, g.getKey(), parca);
                    for (ItemStack artan : p.getInventory().addItem(shard).values()) {
                        p.getWorld().dropItemNaturally(p.getLocation(), artan);
                    }
                    kalan -= parca;
                }
                String ad = g.getKey().endsWith("_e") ? "<gold>Efsanevi " : "<aqua>Güçlü ";
                ad += g.getKey().contains("weapon") ? "Silah" : "Zırh";
                if (ozet.length() > 0) {
                    ozet.append("<gray>, ");
                }
                ozet.append(ad).append(" Shard <white>x").append(g.getValue());
            }
        } catch (ReflectiveOperationException | RuntimeException hata) {
            eklenti.getLogger().warning("Shard uretilemedi: " + hata);
        }
        p.sendMessage(MM.deserialize(mesaj("kir-bitti")
                .replace("<adet>", String.valueOf(adet)).replace("<shard>", ozet.toString())));
        p.playSound(p.getLocation(), Sound.BLOCK_ANVIL_USE, 1f, 1.2f);
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1.1f);
    }
}
