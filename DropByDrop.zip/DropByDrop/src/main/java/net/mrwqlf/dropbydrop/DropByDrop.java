package net.mrwqlf.dropbydrop;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

/**
 * DropByDrop - sinif temali 252 cop silah/zirh. Ozellik yok.
 * Tek komut /dropbydrop (yalnizca dropbydrop.admin); alt komutu yoktur.
 */
public final class DropByDrop extends JavaPlugin {

    static final long MAKS_FIYAT = 1_000_000_000L;

    private Katalog katalog;
    private final MiniMessage mm = MiniMessage.miniMessage();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.katalog = new Katalog(this);
        KatalogMenu menu = new KatalogMenu(this);
        getServer().getPluginManager().registerEvents(new Dinleyici(this, menu), this);

        var komut = getCommand("dropbydrop");
        if (komut != null) {
            CommandExecutor yurutucu = (g, k, e, a) -> {
                if (!(g instanceof Player oyuncu)) {
                    g.sendMessage("Bu komut yalnizca oyunculara ozeldir.");
                    return true;
                }
                if (!oyuncu.hasPermission("dropbydrop.admin")) {
                    oyuncu.sendMessage(mm.deserialize(getConfig().getString("mesajlar.yetkin-yok", "")));
                    return true;
                }
                menu.ac(oyuncu, 0);
                return true;
            };
            komut.setExecutor(yurutucu);
            komut.setTabCompleter((TabCompleter) (g, k, e, a) -> List.of());
        }
        getLogger().info("DropByDrop acildi. Esya sayisi: " + katalog.hepsi().size());
    }

    public Katalog katalog() {
        return katalog;
    }

    /**
     * ShopSistemi bu metodu (reflection ile) cagirir: esya bir katalog esyasiysa
     * ADET BASINA satis fiyatini, degilse -1 doner.
     */
    public long satisFiyati(ItemStack esya) {
        Katalog.Tanim t = katalog.tanimi(esya);
        return t == null ? -1 : fiyat(t);
    }

    /** Esyanin gecerli satis fiyati: once esyaya ozel fiyat, yoksa kademe fiyati. */
    public long fiyat(Katalog.Tanim t) {
        long ozel = getConfig().getLong("fiyat.ozel." + t.id(), -1);
        if (ozel >= 0) {
            return ozel;
        }
        return kademeFiyati(t.kademe());
    }

    public long kademeFiyati(int kademe) {
        return Math.max(0, getConfig().getLong("fiyat.kademe." + kademe, 0));
    }

    public boolean ozelFiyatVarMi(Katalog.Tanim t) {
        return getConfig().getLong("fiyat.ozel." + t.id(), -1) >= 0;
    }

    public void kademeFiyatAyarla(int kademe, long deger) {
        getConfig().set("fiyat.kademe." + kademe, Math.max(0, Math.min(MAKS_FIYAT, deger)));
        saveConfig();
    }

    /** deger < 0 -> esyaya ozel fiyati kaldirir (kademe fiyatina doner). */
    public void ozelFiyatAyarla(Katalog.Tanim t, long deger) {
        getConfig().set("fiyat.ozel." + t.id(), deger < 0 ? null : Math.min(MAKS_FIYAT, deger));
        saveConfig();
    }
}
