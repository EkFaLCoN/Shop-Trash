package net.mrwqlf.dropbydrop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** 252 cop esyanin tanimi + uretimi. Esya kimligi PDC'de saklanir (taklit edilemez). */
public final class Katalog {

    public record Tanim(String id, String sinif, String tur, String ad, Material materyal, int kademe) {
    }

    private static final String[] RENK = {"<#a0643c>", "<gray>", "<dark_gray>", "<white>", "<#c8a070>", "<aqua>", "<gold>"};
    private static final Map<String, String> SINIF_RENK = Map.of(
            "savasci", "<red>", "suikastci", "<dark_purple>", "rahip", "<yellow>",
            "okcu", "<green>", "buyucu", "<blue>", "avci", "<gold>");
    private static final Map<String, String> SINIF_AD = Map.of(
            "savasci", "Savaşçı", "suikastci", "Suikastçı", "rahip", "Rahip",
            "okcu", "Okçu", "buyucu", "Büyücü", "avci", "Avcı");

    private final MiniMessage mm = MiniMessage.miniMessage();
    private final NamespacedKey anahtar;
    private final Map<String, Tanim> tanimlar = new LinkedHashMap<>();

    public Katalog(DropByDrop eklenti) {
        this.anahtar = new NamespacedKey(eklenti, "dbd_id");
        for (String[] v : KatalogVeri.VERI) {
            Material m = Material.matchMaterial(v[4]);
            if (m == null) {
                eklenti.getLogger().warning("Bilinmeyen materyal: " + v[4] + " (" + v[0] + ")");
                continue;
            }
            tanimlar.put(v[0], new Tanim(v[0], v[1], v[2], v[3], m, Integer.parseInt(v[5])));
        }
    }

    public List<Tanim> hepsi() {
        return new ArrayList<>(tanimlar.values());
    }

    public Tanim bul(String id) {
        return tanimlar.get(id);
    }

    /** Esyanin katalog kimligi; katalog esyasi degilse null. */
    public Tanim tanimi(ItemStack e) {
        if (e == null || !e.hasItemMeta()) {
            return null;
        }
        String id = e.getItemMeta().getPersistentDataContainer().get(anahtar, PersistentDataType.STRING);
        if (id == null) {
            return null;
        }
        Tanim t = tanimlar.get(id);
        return (t != null && t.materyal() == e.getType()) ? t : null;
    }

    public ItemStack uret(Tanim t) {
        ItemStack e = new ItemStack(t.materyal());
        ItemMeta meta = e.getItemMeta();
        meta.displayName(mm.deserialize("<!italic>" + RENK[t.kademe() - 1] + t.ad()));
        List<Component> lore = new ArrayList<>();
        lore.add(mm.deserialize("<!italic><dark_gray>Çöp eşya <gray>· "
                + SINIF_RENK.get(t.sinif()) + SINIF_AD.get(t.sinif()) + " <gray>temalı"));
        if (t.kademe() >= 6) {
            lore.add(Component.empty());
            lore.add(mm.deserialize(t.kademe() == 7
                    ? "<!italic><gold>✦ Kadim eşya <gray>· <white>/salvage <gray>ile kır:"
                    : "<!italic><aqua>✦ Parlayan eşya <gray>· <white>/salvage <gray>ile kır:"));
            lore.add(mm.deserialize(t.kademe() == 7
                    ? "<!italic><gray>  1-3 <gold>Efsanevi <gray>" + (t.tur().equals("silah") ? "Silah" : "Zırh") + " Shard'ı"
                    : "<!italic><gray>  1-3 <aqua>Güçlü <gray>" + (t.tur().equals("silah") ? "Silah" : "Zırh") + " Shard'ı"));
            meta.setEnchantmentGlintOverride(true);
        }
        meta.lore(lore);
        meta.setItemModel(new NamespacedKey("dropbydrop", t.id()));
        meta.getPersistentDataContainer().set(anahtar, PersistentDataType.STRING, t.id());
        e.setItemMeta(meta);
        if (t.tur().equals("zirh")) {
            giyilemezYap(e);
        }
        return e;
    }

    /**
     * Cop zirhin "equippable" bileseni kaldirilir: istemci de sunucu da esyayi artik zirh
     * olarak tanimaz; sag tikla / tikla-tasi ile giyilmeye calisilirken ne tahmin ne iptal
     * kaynakli kaybolma olur. Paper'in data component API'si yansima ile cagrilir
     * (surum farkinda derleme hatasi vermesin); basarisiz olursa olay tabanli engel devrededir.
     */
    private static void giyilemezYap(ItemStack e) {
        try {
            Class<?> turler = Class.forName("io.papermc.paper.datacomponent.DataComponentTypes");
            Class<?> tur = Class.forName("io.papermc.paper.datacomponent.DataComponentType");
            Object equippable = turler.getField("EQUIPPABLE").get(null);
            ItemStack.class.getMethod("unsetData", tur).invoke(e, equippable);
        } catch (ReflectiveOperationException | RuntimeException | LinkageError yoksay) {
            // eski surum: olay tabanli engel yeterli
        }
    }
}
